import math

# parent class
class Shape:
    counter = 0

    def __init__(self):
        Shape.counter += 1
        self.id = Shape.counter

    def countReset(self):
        Shape.counter = 0

    def print_info(self):
        print(self.id, end=": ")
        print(type(self).__name__, end=" ")
        perimeter = self.perimeter()
        if perimeter is None:
            perimeter = "undefined"
        print("perimeter:", perimeter, end=" ")

        area = self.area()
        if area is None:
            area = "undefined"
        print("area:", area)

    def getCount(self):
        return Shape.counter

    def perimeter(self):
        return None

    def area(self):
        return None


# child circle class
class Circle(Shape):
    circleCounter = 0

    def __init__(self, radius):
        super().__init__()
        self.radius = radius
        Circle.circleCounter += 1

    def countReset(self):
        Circle.circleCounter = 0

    def getCount(self):
        return Circle.circleCounter

    def perimeter(self):
        return round(2 * math.pi * self.radius, 5)

    def area(self):
        return round(math.pi * self.radius**2, 5)


# child ellipse class
class Ellipse(Shape):
    ellipseCounter = 0

    def __init__(self, a, b):
        super().__init__()
        self.semi_major = max(a, b)
        self.semi_minor = min(a, b)
        Ellipse.ellipseCounter += 1

    def getCount(self):
        return Ellipse.ellipseCounter

    def countReset(self):
        Ellipse.ellipseCounter = 0

    def area(self):
        return round(math.pi * self.semi_major * self.semi_minor, 5)

    def eccentricity(self):
        try:
            return round(math.sqrt(self.semi_major**2 - self.semi_minor**2), 5)
        except ValueError:
            return None

    def print_info(self):
        print(self.id, end=": ")
        print(type(self).__name__, end=", ")
        perimeter = self.perimeter()
        if perimeter is None:
            perimeter = "undefined"
        print("perimeter:", perimeter, end=", ")

        area = self.area()
        if area is None:
            area = "undefined"
        print("area:", area, end=", ")
        linEcc = self.eccentricity()
        if linEcc is None:
            linEcc = "undefined"
        print("linear eccentricity:", linEcc)


# child rhombus class
class Rhombus(Shape):
    rhombusCounter = 0

    def __init__(self, diagonal1, diagonal2):
        super().__init__()
        self.diagonal1 = diagonal1
        self.diagonal2 = diagonal2
        Rhombus.rhombusCounter += 1

    def getCount(self):
        return Rhombus.rhombusCounter

    def countReset(self):
        Rhombus.rhombusCounter = 0

    def perimeter(self):
        return 4 * self.side()

    def area(self):
        return round((self.diagonal1 * self.diagonal2) / 2, 5)

    def side(self):
        return round(math.sqrt(self.diagonal1**2 + self.diagonal2**2) / 2, 5)

    def inradius(self):
        try:
            return round((self.diagonal1 * self.diagonal2) / (4 * self.side()), 5)
        except ZeroDivisionError:
            return None

    def print_info(self):
        print(self.id, end=": ")
        print(type(self).__name__, end=", ")
        perimeter = self.perimeter()
        if perimeter is None:
            perimeter = "undefined"
        print("perimeter:", perimeter, end=", ")

        area = self.area()
        if area is None:
            area = "undefined"
        print("area:", area, end=", ")
        print("side:", self.side(), end=", ")
        onRadius = self.inradius()
        if onRadius is None:
            onRadius = "undefined"
        print("in-radius:", onRadius)
        
def countReset():
    Circle.circleCounter =0
    Shape.counter = 0
    Rhombus.rhombusCounter  = 0
    Ellipse.ellipseCounter = 0

