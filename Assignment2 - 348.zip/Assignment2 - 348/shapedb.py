from Methods import *
#methods for menu
def load_file():
   
    print("LOAD option selected")
    print("Enter file name you wish to Load ( end with .txt)")
    choice = input("Enter your choice: ")
    LOAD(choice)
    

def to_set():
    print("TOSET option selected")
    TOSET()
    

def save_file():
    print("SAVE option selected")
    print("Enter file name you wish to save to( end with .txt)")
    choice = input("Enter your choice: ")
    SAVE(choice)
    

def print_database():
    print("PRINT option selected")
    PRINT()

def print_summary():
    print("SUMMARY option selected")
    SUMMARY()

def print_details():
    print("DETAILS option selected")
    DETAILS()

options = {
    "LOAD": load_file,
    "TOSET": to_set,
    "SAVE": save_file,
    "PRINT": print_database,
    "SUMMARY": print_summary,
    "DETAILS": print_details,
    "QUIT": quit
}

while True:
    print("\n----- Shape Database Menu -----:")
    print("1. LOAD")
    print("2. TOSET")
    print("3. SAVE")
    print("4. PRINT")
    print("5. SUMMARY")
    print("6. DETAILS")
    print("7. QUIT")

    choice = input("Enter your choice: (type the name of the operation) ")

    if choice in options:
        options[choice]()  
    else:
        print("Invalid choice. Please try again.")

    if choice == "QUIT":
        print("Thank you for using the Shape Database program")
        break

