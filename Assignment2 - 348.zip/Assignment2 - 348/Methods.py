from Shape import *
import os

#global variables to keep track of statistics
errorCount = 0
lineCount = 0
listOfLines = []
shapeList = []

#list which holds names of valid shapes
shapeSet = ["shape", "circle", "rhombus", "ellipse"]


#reads shape objects
def shapeReader(shapeList, line):

    global lineCount
    lineCount += 1

    line2 = line.strip()
    lineList = line2.split()

    if lineList[0] in shapeSet:
        shapeObj = shapeCreater(lineList, lineCount, line2)
        if shapeObj != None:
            shapeList = shapeList.append(shapeObj)
    else:
        global errorCount
        errorCount += 1
        print("Error: Invalid Shape on " + lineCount + ": " + line)

#load method
def LOAD(txtName):

    global lineCount
    global shapeList
    global errorCount
    global listOfLines

    errorCount = 0
    listOfLines.clear()
    shapeList.clear()
    lineCount = 0
    countReset()
    
    with open(txtName, "r") as file:
        filepath = os.path.abspath(txtName)
        print("Processing " + filepath)
        for line in file:
            shapeReader(shapeList, line)
    print(
        "Processed "
        + str(lineCount)
        + " row(s), "
        + str(Shape.counter)
        + " shape(s) added, "
        + str(errorCount)
        + " error(s)"
    )
    for x in listOfLines:
        print(x)


def shapeCreater2(line):

    lsd = " ".join(line)
    obj = None
    if line[0] == shapeSet[0]:
        if len(line) > 1 or len(line) == 0:
            print("Error: Invalid Shape on line: " + str(0) + ": " + lsd)
        else:
            obj = Shape()
    elif line[0] == shapeSet[1]:
        if len(line) > 2 or len(line) <= 1:
            errorCount += 1
            print("Error: Invalid Circle on line: " + str(0) + ": " + lsd)
        elif int(line[1]) <= 0:
            errorCount += 1
            print("Error: Invalid Circle on line: " + str(0) + ": " + lsd)
        else:
            obj = Circle(int(line[1]))
    elif line[0] == shapeSet[2]:
        if len(line) > 3 or len(line) <= 1:
            errorCount += 1
            print("Error: Invalid Rhombus on line: " + str(0) + ": " + lsd)
        elif int(line[1]) <= 0 or int(line[2]) <= 0:
            errorCount += 1
            print("Error: Invalid Rhombus on line: " + str(0) + ": " + lsd)
        else:
            obj = Rhombus(int(line[1]), int(line[2]))
    elif line[0] == shapeSet[3]:
        if len(line) > 3 or len(line) <= 1:
            errorCount += 1
            print("Error: Invalid Ellipse on line: " + str(0) + ": " + lsd)
        elif int(line[1]) <= 0 or int(line[2]) <= 0:
            errorCount += 1
            print("Error: Invalid Ellipse on line: " + str(0) + ": " + lsd)
        else:
            obj = Ellipse(int(line[1]), int(line[2]))
    return obj


def shapeCreater(line, lineNumber=0, lsd="xxx"):
    global errorCount
    global listOfLines

    obj = None
    if line[0] == shapeSet[0]:
        if len(line) > 1 or len(line) == 0:
            print("Error: Invalid Shape on line: " + str(lineNumber) + ": " + lsd)
        else:
            listOfLines.append(line)
            obj = Shape()
    elif line[0] == shapeSet[1]:
        if len(line) > 2 or len(line) <= 1:
            errorCount += 1
            print("Error: Invalid Circle on line: " + str(lineNumber) + ": " + lsd)
        elif int(line[1]) <= 0:
            errorCount += 1
            print("Error: Invalid Circle on line: " + str(lineNumber) + ": " + lsd)
        else:
            listOfLines.append(line)
            obj = Circle(int(line[1]))
    elif line[0] == shapeSet[2]:
        if len(line) > 3 or len(line) <= 1:
            errorCount += 1
            print("Error: Invalid Rhombus on line: " + str(lineNumber) + ": " + lsd)
        elif int(line[1]) <= 0 or int(line[2]) <= 0:
            errorCount += 1
            print("Error: Invalid Rhombus on line: " + str(lineNumber) + ": " + lsd)
        else:
            listOfLines.append(line)
            obj = Rhombus(int(line[1]), int(line[2]))
    elif line[0] == shapeSet[3]:
        if len(line) > 3 or len(line) <= 1:
            errorCount += 1
            print("Error: Invalid Ellipse on line: " + str(lineNumber) + ": " + lsd)
        elif int(line[1]) <= 0 or int(line[2]) <= 0:
            errorCount += 1
            print("Error: Invalid Ellipse on line: " + str(lineNumber) + ": " + lsd)
        else:
            listOfLines.append(line)
            obj = Ellipse(int(line[1]), int(line[2]))
    return obj


def PRINT():
    for x in shapeList:
        x.print_info()


def SUMMARY():
    print("Circle(s): " + str(Circle.circleCounter))
    print("Ellipse(s): " + str(Ellipse.ellipseCounter))
    print("Rhombus(es): " + str(Rhombus.rhombusCounter))
    print("Shape(s): " + str(Shape.counter))


def DETAILS():
    for x in listOfLines:
        y = " ".join(x)
        print(y)


def TOSET():
    global shapeList
    global listOfLines

    countReset()
    
    toopy = [tuple(lst) for lst in listOfLines]

    unList = set()
    for x in toopy:
        unList.add(x)

    listOfLines.clear()

    copy_list = [list(tpl) for tpl in unList]

    for x in copy_list:
        listOfLines.append(x)

    shapeList.clear()
    for x in listOfLines:
        obj = shapeCreater2(x)
        shapeList.append(obj)

def SAVE(txt_name):
    
    with open(txt_name, "w") as file:
        for x in listOfLines:
            y = " ".join(x) + "\n"
            file.write(y)
            
